@extends('layouts.app')

@section('content')


<div class="page-title-area">
    <div class="container">
        <div class="page-title-content">
            <h2>Terms of service</h2>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li>Terms of service</li>
            </ul>
        </div>
    </div>
</div>


<section class="terms-of-service-area ptb-50">
    <div class="container">
        <div class="faq-accordion">
            <ul class="accordion">
                <li class="accordion-item">
                    <a class="accordion-title active" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        THE AGREEMENT
                    </a>
                    <p class="accordion-content">
                Diamond Review Africa , provides its Services to you subject to the Terms of Service outlined in this document,
                which may be updated by Diamond Review from time to time without notice to you. By accessing the Services,
                you acknowledge that you have read and understood these Terms of Service, and agree to abide by them.
                The Terms of Service is the entire agreement regarding your usage of the Services, and supersedes any oral
                or written communication between you and any employee, officer, or affiliate of Diamond Review Africa.
                 Any waiver of any provision of the Terms of Service will be effective only if in writing and signed by Diamond Review Africa.
                The Terms of Service and the relationship between you and Diamond Review Africa, shall be governed by the
                laws of the State of Washington without regard to its conflict of law provisions. You and Diamond Review Africa
                agree to submit to the personal and exclusive jurisdiction of the courts located within King County, Washington.
                 You and Diamond Review Africa agree to conduct all legal proceedings exclusively in the English language.
                  The failure of Diamond Review Africa to exercise or
                enforce any right or provision of the Terms of Service shall not constitute a waiver of such right or provision.
                 If any provision of the Terms of Service is found by a court of competent jurisdiction to be invalid,
                 the parties nevertheless agree that the court should endeavor to give effect to the parties' intentions
                 as reflected in the provision, and the other provisions of the Terms of Service remain in full force and effect.
                  Regardless of any statute or law to the contrary, you agree to send written notice to
                   Diamond Review Africa as set forth in Section 9, detailing any claim or cause of action
                   arising out of or related to your use of the Services or the Terms of Service within one
                   (1) year after such claim or cause of action arose, or be forever barred from pursuing such
                    claim or cause of action.
                    </p>
                </li>

                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        ACCESS TO THE SERVICE
                    </a>
                    <p class="accordion-content">
                        In order to use the Services, you may need to obtain access to the World Wide Web,
                         either directly or through devices that access web-based content, and pay any service
                          fees associated with such access. In addition, you must provide, at your expense,
                          all equipment necessary to make such connection to the World Wide Web, including, but not limited to,
                           a computer and modem or other access device.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        LIMITATION OF RELIABILITY AND ENDORSEMENTS
                    </a>
                    <p class="accordion-content">
                        Diamond Review does not represent or endorse the accuracy or reliability of any of the information,
                         content, messages, graphics, drawings, user reviews, or advertisements contained on, distributed through,
                         or linked, downloaded or accessed from the Services nor the quality of any products, information or other materials displayed, purchased, or obtained by you as a result of an advertisement or any other information or offer in or in connection with the Services.
                        'Your correspondence or business dealings with, or participation in promotions of, advertisers,
                        vendors, or users found on or through the Services, including payment and delivery of related goods or services,
                         and any other terms, conditions, warranties or representations associated with such dealings, are solely between
                          you and such advertiser, vendor, or user. You agree that Diamond Review shall not be responsible or
                          liable for any loss or damage of any sort incurred as the result of any such dealings or as the result of
                           the presence of such advertisers, vendors, or users on the Services.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        ERRORS AND OMISSIONS
                    </a>
                    <p class="accordion-content">
                        Diamond Review is not responsible for any errors or omissions,
                        or for any losses you or any other third party might incur as a result of our errors or omissions,
                        even if we have been previously advised of such errors or omissions.
                        If you believe there is an error in the Services, you may contact us.
                        Any changes we make to the Services as a result of your feedback are at our sole discretion,
                        and we are under no obligation to make any changes you may suggest.
                         Diamond Review Africa reserves the right, in its sole discretion and without any obligation,
                         to make improvements to, or correct any errors or omissions in the Services without notice to you.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        EXTERNAL SITES AND RESOURCES
                    </a>
                    <p class="accordion-content">
                        Diamond Review Africa is not responsible for the availability, accuracy,
                        copyright compliance, legality or decency of material contained in any external
                         link or other external resource, including advertisers, that you may access from the Services.
                          You further acknowledge and agree that Diamond Review Africa shall not be responsible or liable,
                           directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection
                           with use of or reliance on any such external content, goods or services.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        INTELLECTUAL PROPERTY
                    </a>
                    <p class="accordion-content">
                        Diamond Review Africa respects the intellectual property rights of others,
                        and we ask our users to do the same. All information, data, text, software, music, sound,
                         photographs, graphics, video, messages, or other materials, whether publicly
                          posted or privately transmitted, are the sole responsibility of the person from which it originated.
                           You, and not Diamond Review Africa, are entirely responsible for anything you upload, email, post,
                           or otherwise transmit to us. You agree not to transmit any information to us in any way that
                            would constitute copyright infringement. Accounts of repeat infringers will be terminated
                            in appropriate circumstances. If any content within the Services contains what you believe to
                             be your work in a way that constitutes copyright infringement,
                         please notify us immediately by following the procedure set forth below.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        REGISTRATION AND PRIVACY POLICY

                    </a>
                    <p class="accordion-content">
                        There are certain sections within the Services that require registration. By registering,
                        you agree to provide true and accurate information as requested, and to make timely updates
                        if any of your personal information changes. You are fully responsible for all activity that
                         occurs under your password or account,
                         and you agree to keep your password and account confidential.
                         We record your email address and other personally identifying information
                          if you choose to communicate with us via e-mail or if you choose to register.
                          Our use and disclosure of such information is governed by the Privacy Policy, which is available by visiting.
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        OUR RIGHT TO DISCONTINUE SERVICE                    </a>
                    <p class="accordion-content">
                        Diamond Review Africa reserves the right at any time and from time
                        to time to modify or discontinue, temporarily or permanently, the Services
                         with or without notice. You agree that Diamond Review shall not be liable to
                         you or to any third party for any modification, suspension or discontinuance of
                         any or all of the Services. You agree that Diamond Review Africa , in its sole discretion,
                          may terminate or restrict your account for any reason whatsoever, with or without notice.

                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        LEGAL NOTICES
                       </a>
                    <p class="accordion-content">
                        You agree to send or cause to have sent any and all legal notices and all legal matters to:
                        PO Box, 103 Lanacre Avenue, 25 Iris Court London NW9 5AN.
                        Post: 103 Lanacre Avenue, 25 Iris Court London NW9 5AN.
                        Email: subscriptions@diamondreviewafrica.com; customerservices@diamondreviewafrica.com
                        You agree that any and all legal notices and legal matters sent to us in any other way
                        (such as, for example,
                        through email, fax, or our website) will have no legal effect and may not be processed.

                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        OUR PROPRIETARY CONTENT
                       </a>
                    <p class="accordion-content">
                        You acknowledge and agree that the Services contain information that is protected by applicable intellectual
                        property and other laws. You further acknowledge and agree that content contained in sponsor advertisements
                         or information presented to you through the Services, advertisers, or users may be protected by copyrights,
                         trademarks, service marks, patents or other laws. You agree not to modify, rent, lease, loan, sell, distribute
                         or create derivative works based on the Services, in whole or in part.
                        You further agree that all information and data you submit to or through the Services becomes the property
                         of Diamond Review.
                        We welcome your suggestions to improve the Services. However, if you choose to submit such suggestions,
                         you acknowledge that you do so voluntarily, and in doing so you agree to assign to Diamond Review Africa
                         all rights to any and all such suggestions (including patentable inventions), and to make best efforts to
                         assist Diamond Review Africa in the filing, prosecution, or other perfection of any such intellectual
                         property rights. You further agree not to assert any claims against Diamond Review Africa under any
                         intellectual property rights you may have obtained that are based in whole or in part on any voluntary
                         suggestions you may have submitted to us,
                        or to permit or assist others to assert any such claims.
                    </p>
                </li>
            </ul>
        </div>
    </div>
</section>







@endsection
