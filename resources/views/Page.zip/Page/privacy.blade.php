@extends('layouts.app')

@section('content')




<div class="page-title-area">
    <div class="container">
        <div class="page-title-content">
            <h2>Privacy policy</h2>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li>Privacy policy</li>
            </ul>
        </div>
    </div>
</div>


<section class="privacy-policy-area ptb-50">
    <div class="container">
        <div class="faq-accordion">
            <ul class="accordion">
                <li class="accordion-item">
                    <a class="accordion-title active" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        Which material types can you work with?
                    </a>
                    <p class="accordion-content show">
                        Diamond Review values and respects your privacy. We stand united with many other
                         responsible websites AGAINST "SPAMMING" and other intrusive mass-marketing tactics.
                        We collect the following categories of personally identifiable information:
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        What access do I have on the free plan?
                    </a>
                    <p class="accordion-content">
                        1. The IP address of any computer/network you use to access this web site.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        Can I have multiple activities in a single feature?
                    </a>
                    <p class="accordion-content">
                        2. If you wish to post messages on the forum, we will
                         collect your email address and username prior to allowing you to post any such messages.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        Which material types can you work with?
                    </a>
                    <p class="accordion-content">
                        We will not disclose your personally-identifying information to any third party without your opt-in permission.
                         The exceptions: 1) when required by law wherein we have a good-faith belief that such action is necessary to comply
                         with a current judicial proceeding, subpoena, court order, law enforcement, or other legal process, 2) if you conduct
                         a prohibited activity as set forth in our Terms of Service, in which case we may disclose your personal information
                         to enforcement organizations or affected third parties, 3) our service providers (such as web hosting, etc.), and 4)
                         if the website is acquired by a third party, in which case we will make a reasonable effort to contractually require
                         the acquirer to treat
                         your personally-identifying information in a manner that is similar to this Privacy Policy.
                         E-mails you receive from us will generally fall under the following three categories: 1)
                         Verification of personal information to allow us to open your account or reset your password,
                         2) At your request during registration, we may e-mail you our newsletter, and 3)
                         At your request when using our forum, we will e-mail
                         you when someone posts a reply to your questions or similar forum functions.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        Why choose our services in your business?
                    </a>
                    <p class="accordion-content">
                        Please be aware that this website includes functionality that lets you publicly post freeform messages and other content, including information that may be used by others to identify you personally.
                         For example, the public profile function in the forum area allows you to voluntarily post your name, birthday,
                         photographs, and other personal information. Likewise, while we discourage doing so, it is certainly possible
                         for you to post your own email address or other personal information in a public message in the forum.
                          Any personal information voluntarily posted in a public area is expressly excluded from this Privacy Policy.
                        This privacy policy is effective as of the date shown above.
                        We are committed to the ever-increasing flow of free information on the Internet, while being respectful
                         about your privacy. Should you have any questions or concerns about our Privacy Policy, please send us a
                          message by clicking on the "Contact Us" link at the bottom of every page of this site.
                    </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        How long do we keep your data?                    </a>
                    <p class="accordion-content">
                        Data about your browsing our website will be kept only for the duration of the session. However,
                         cookies may last longer on your device so we can identify you upon your next visit.
                        Registrations for events or newsletters will be kept until after the event or until you unsubscribe
                        from our newsletters.
                        Information about visitors at our premises are kept for 30 days or longer if required for security
                        purposes or to investigate an incident.
                        Other personal data that we have will be retained for the duration that is relevant for the purpose as
                         set out above, in accordance to internal retention periods,
                        taking into account contractual or legal obligations and liability that we may have to keep records
                        of our files.
                                            </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        Governing law and jurisdiction stipulation
                    </a>
                    <p class="accordion-content">
                        This Data Protection Notice shall be governed, interpreted and enforced in accordance
                        with Belgian law, which applies exclusively for any litigation.
                    Antwerp courts have exclusive jurisdiction to rule on any dispute that may
                    arise from the interpretation or
                    implementation of this Data Protection Notice.
                      </p>
                </li>
                <li class="accordion-item">
                    <a class="accordion-title" href="javascript:void(0)">
                        <i class='bx bx-plus'></i>
                        Do I need a blog?
                    </a>
                    <p class="accordion-content">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </p>
                </li>
            </ul>
        </div>
    </div>
</section>



@endsection
